package pojo;

public class DeletePlaceRequest {
	private String place_id;

	public String getPlace_id() {
		return place_id;
	}

	public void setPlace_id(String place_id) {
		this.place_id = place_id;
	}

}
