import java.util.Base64;

import javax.crypto.Cipher;
import javax.crypto.SecretKey;
import javax.crypto.spec.IvParameterSpec;
import javax.crypto.spec.SecretKeySpec;

public class Decreatption {

	public static void main(String[] args) throws Exception {
		String email = "kitap2@kairos.com";
        String password = "Password@1";

        String encryptedText = encrypt(email + ":" + password);
        System.out.println(encryptedText);
    

	}
	public static String encrypt(String text) throws Exception {
        String key = "0123456789abcdef"; // 16 characters for AES-128
        String iv = "9876543210abcdef"; // 16 characters for AES-128

        Cipher cipher = Cipher.getInstance("AES/CBC/PKCS5PADDING");
        SecretKey secretKey = new SecretKeySpec(key.getBytes(), "AES");
        cipher.init(Cipher.ENCRYPT_MODE, secretKey, new IvParameterSpec(iv.getBytes()));

        byte[] encryptedBytes = cipher.doFinal(text.getBytes());
        return Base64.getEncoder().encodeToString(encryptedBytes);
    }

}
