import java.time.Duration;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.ui.WebDriverWait;

public class Swap {

	public static void main(String[] args) {
		//each word reverse string but positions are different
		/*
		 * String name="welcome to java"; String rev=""; for(int
		 * i=0;i<name.length();i++) { rev=name.charAt(i)+rev; } System.out.println(rev); avaj ot emoclew   

		 */
		//each word reverse string but positions same
		/*
		 * String name="welcome to java"; String splitword[]=name.split(" "); String
		 * reversestring=""; for(String eachword: splitword) { String rev=""; for(int
		 * i=0;i<eachword.length();i++) { rev=eachword.charAt(i)+rev; }
		 * reversestring=reversestring+rev+" "; } System.out.println(reversestring);   emoclew ot avaj 
		 */
	//reverse of a String but only positions
		
	    String input="welcome to java khaja";
	
		String reversedString=reverseWords(input);
		
        System.out.println("original String "+input);
        System.out.println("reversed String "+reversedString);
        
	}    
        public static String reverseWords(String input) {
        	String words[]=input.split(" ");
        	for(int i=0,j=words.length-1;i<j;i++,j--) {
        		String temp=words[i];
        		words[i]=words[j];
        		words[j]=temp;
        	}
        	return String.join(" ", words);////khaja java to welcome
        }
        
       
  
		
		
}	
		
		
		
		
		
		
		
		
		
		
		
		
//		
		      /**  String input = "welcome to java";

		        // Reverse the words in the string
		        String reversedString = reverseWords(input);

		        // Display the result
		        System.out.println("Original String: " + input);
		        System.out.println("Reversed String: " + reversedString);
		    }

		    // Method to reverse the words in a string without using StringBuilder
		    private static String reverseWords(String input) {
		        String[] words = input.split("\\s"); // Split the input string into words

		        // Reverse the array of words in-place
		        for (int i = 0, j = words.length - 1; i < j; i++, j--) {
		            // Swap words at indices i and j
		            String temp = words[i];
		            words[i] = words[j];
		            words[j] = temp;
		        }

		        // Join the reversed words to form the reversed string
		        return String.join(" ", words);*/
		    



//41 43 47 53 59 61 67 71 73 79 83 89 97








//0, 1, 1, 2, 3, 5, 8, 13, 21