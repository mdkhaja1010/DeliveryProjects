package upCasting;

public class Child extends Parent {
	 void PrintData() {  
	      System.out.println("method of child class");  
	   }  

}
