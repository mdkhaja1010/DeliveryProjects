package upCasting;

public class Parent {
	void PrintData() {  
	      System.out.println("method of parent class");  
}
}
