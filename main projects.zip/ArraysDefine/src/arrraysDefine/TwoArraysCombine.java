package arrraysDefine;

import java.util.HashSet;
import java.util.TreeSet;

public class TwoArraysCombine {
	public static void main(String[] args) {
		int a[]= {7,2,7,4,1,5,3,3,5,6,13};
		int b[]= {1,2,3,4,5,6,7,10,14,10,11,8,12,9,9,11,12};
		
		int length1=a.length;
		int length2=b.length;
		int c[]=new int[length1+length2];
		for(int i=0;i<length1;i++) {
			c[i]=a[i];
		}
		for(int i=0;i<length2;i++) {
			c[i+length1]=b[i];
		}
		HashSet<Integer> myset=new HashSet<Integer>();
		for(int i=0;i<c.length;i++) {
			myset.add(c[i]);
		}
		TreeSet<Integer>mysets=new TreeSet<Integer>(myset);
		for(int num:mysets.descendingSet()) {
		System.out.print(" "+num);
		
		}
	}

}
