package arrraysDefine;

public class ChildClassOveride extends MethodOverRide{
	 public  int add(int a, int b, int c) {
		System.out.println(a + b + c);
		return a + b + c;
	}


}
