package arrraysDefine;

public class ArrayDeclarations {
	public static void main(String[] args) {
		int a[]=new int[9];
		a[0]=10;
		a[1]=1;
		a[9]=20;
		a[10]=11;
		a[0]=10;
		a[1]=1;
		a[9]=20;
		a[10]=11;
		a[0]=10;
		a[1]=1;
		a[9]=20;
		a[10]=11;
		System.out.println(a[10]);
		
	}

}
