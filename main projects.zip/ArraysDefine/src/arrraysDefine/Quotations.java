package arrraysDefine;

public class Quotations {
	
	   public static int secondlargestNum(int a[]) {
		   for(int i=0;i<a.length;i++) {
			   for(int j=i+1;j<a.length;j++) {
				   if(a[i]<a[j]) {
					   int temp=a[i];
					   a[i]=a[j];
					   a[j]=temp;
				   }
			   }
			   System.out.print(" "+a[i]);
		   }
		   System.out.println("\n");
		   int count=1;
		   int largest=a[0];
		   for(int i=1;i<a.length;i++) {
			   if(a[i]!=largest) {
				   largest=a[i];
				   count++;
			   }
			   if(count==3) {
				   return a[i];
			   }
		   }
		   return -1;
	   }
	   public static void main(String[] args) {
		int a[]= {2,3,1,3,2,5,4,5,4,5,6};
		System.out.println("the second largest number is "+secondlargestNum(a));
	}
}
