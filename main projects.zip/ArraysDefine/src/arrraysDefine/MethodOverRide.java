package arrraysDefine;

public class MethodOverRide {
	public int add(int a, int b) {
		System.out.println(a + b);

		return a + b;

	}

	
	
}