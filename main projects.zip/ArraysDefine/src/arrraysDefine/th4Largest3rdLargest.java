package arrraysDefine;

public class th4Largest3rdLargest {
	
	public static int thirdLargest(int[] a) {
        // Sort the array
        for (int i = 0; i < a.length; i++) {
            for (int j = i + 1; j < a.length; j++) {
                if (a[i] < a[j]) {
                    int temp = a[i];
                    a[i] = a[j];
                    a[j] = temp;
                }
            }
            System.out.print(" "+a[i]);
            
        }
        System.out.println("\n");

        // Find the third largest number
        int largest = a[0];
        int count = 1; // To track unique numbers

        for (int i = 1; i < a.length; i++) {
            if (a[i] != largest) {
                largest = a[i];
                count++;
            }
            if (count == 2) {
                return a[i];
            }
        }

        // If there are less than 3 unique numbers
        return -1; // Adjust as needed
    }

    public static void main(String[] args) {
        int[] a = {2, 6, 1, 3, 5, 4, 9, 8,8, 10, 7, 7, 9};
        System.out.println("The third largest number in the given array is " + thirdLargest(a));
    }

}
