package arrraysDefine;

public class StringDemo {

	public static void main(String[] args) {
          String s1="khaja";
          String s2="khaja";
          System.out.println(s1==s2);
          
          s1=s1+"mohammed";
          System.out.println(s1==s2);
     
          String s3="mohammedkhaja";
          System.out.println(s1==s3);
        		  
	}

}
