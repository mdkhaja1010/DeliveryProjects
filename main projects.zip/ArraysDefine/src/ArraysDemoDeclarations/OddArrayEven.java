package ArraysDemoDeclarations;

public class OddArrayEven {
	public static void main(String[] args) {
		int evencount=0, oddcount=0;
		int a[]= {1234,3342,323,9898,1,33,123,12345,9909};
		for(int i=0;i<a.length;i++) {
			int ch=a[i], count=0;; 
			  while(ch!=0) {
				 ch=ch/10;
				 count++;
			 }
			if(count%2==0) {
				
				evencount++;
				System.out.println(a[i]+" is a even number count");
				
			}else {
				
				oddcount++;
				System.out.println(a[i]+" is a odd number count");
			}
		}
		System.out.println(evencount);
		System.out.println(oddcount);

		
	}

}
