package ArraysDemoDeclarations;

public class ReverseArray {

	public static void main(String[] args) {
		int a[]= {23,92,11,8,50,89,10};
		for(int i=a.length-1;i>=0;i--) {
			System.out.println(a[i]);
		}

	}

}
