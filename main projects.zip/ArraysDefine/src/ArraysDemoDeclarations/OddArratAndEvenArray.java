package ArraysDemoDeclarations;

public class OddArratAndEvenArray {
	public static void main(String[] args) {
		
	
	int[] array= {112,2345,5467};
	
	int evenCount=0;
	
	for(int i=0;i<array.length;i++) {
		String strConvNum=String.valueOf(array[i]);
		
		if(strConvNum.length()%2==0) {
			System.out.println(array[i]);
			
		}
	}
	}
}
