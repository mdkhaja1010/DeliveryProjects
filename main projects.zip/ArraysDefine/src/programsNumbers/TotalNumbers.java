package programsNumbers;

public class TotalNumbers {
	
	public static void main(String[] args) {
		int num=122988;
		int count=0;
		while(num!=0) {
			num=num/10;
			count++;
		}
		System.out.println("the total numbers of given interger is "+count);
	}

}
