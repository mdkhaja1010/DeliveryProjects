package programsNumbers;

public class Tables2 {
	public static void main(String[] args) {
		for(int i=1;i<=10;i++) {
			int num=3;
			int count=num*i;
			System.out.println(num+" X "+i+ " = "+count);
		}
	}

}
