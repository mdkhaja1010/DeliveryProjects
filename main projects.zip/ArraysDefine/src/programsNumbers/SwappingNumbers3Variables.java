package programsNumbers;

public class SwappingNumbers3Variables {

	public static void main(String[] args) {
		int a=10,b=5,c;
		c=a;
		a=b;
		b=c;
		System.out.println(a);
		System.out.println(b);

	}

}
