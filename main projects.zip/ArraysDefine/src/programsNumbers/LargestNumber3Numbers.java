package programsNumbers;

public class LargestNumber3Numbers {

	public static void main(String[] args) {
		int a=99,b=150,c=101;
		if(a>b && a>c) {
			System.out.println("the largest number is a: "+a);
			
		}
		else if(b>c) {
			System.out.println("the largest number is b: "+b);
		}
		else {
			System.out.println("the largest number is c: "+c);
		}
	}

}
