package programsNumbers;

public class SwappingNumber {

	public static void main(String[] args) {
		int a=10,b=25;
		a=a+b;
		b=a-b;
		a=a-b;
		System.out.println(a);
		System.out.println(b);

	}

}
