package programsNumbers;

import java.util.Scanner;

public class Numbers1to10 {

	public static void main(String[] args) {
		
//		System.out.println("enter the number");
//		Scanner sc = new Scanner(System.in);
//		int num = sc.nextInt();
//		while (num <= 1 || num > 10) {
//			System.out.println("please try again");
//			num = sc.nextInt();
//		}
//		System.out.println("number is correct");
		 
		String name = "123";
		int intNumber = Integer.parseInt(name);
		System.out.println(intNumber+20);
		int intnumer1 = 1233;
		String stringNumber = Integer.toString(intnumer1);
		System.out.println(stringNumber+89);
		
	}

}
