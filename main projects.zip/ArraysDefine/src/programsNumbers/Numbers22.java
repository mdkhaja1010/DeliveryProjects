package programsNumbers;

public class Numbers22 {

	public static void main(String[] args) {
        for(int i=1;i<=10;i++) {
        	int num=3;
        	int sum=num*i;
        	System.out.println(num+" X "+i+" = "+sum);
        }
         
	}
}