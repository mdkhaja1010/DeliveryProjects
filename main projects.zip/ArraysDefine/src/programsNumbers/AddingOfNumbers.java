package programsNumbers;

public class AddingOfNumbers {

	public static void main(String[] args) {
		int num=9,sum=0;
		for(int i=1;i<=num;i++) {
			sum=sum+i;
		}
		System.out.println(sum);
	
	}

}
