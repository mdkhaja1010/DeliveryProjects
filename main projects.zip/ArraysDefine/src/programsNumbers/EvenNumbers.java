package programsNumbers;

public class EvenNumbers {

	public static void main(String[] args) {
	    int name=50;
	    for(int i=0;i<name;i++) {
	    	if(i%2==0) {
	    	System.out.println(i);
	    }
	    }

	}

}
