package multipleInheritance;

public class AB implements A,B{
	public void Adisplay() {
		   System.out.println("this is a A display method");
	   }
	   public void Bdisplay() {
		   System.out.println("this is a B display method");
	   }
}
