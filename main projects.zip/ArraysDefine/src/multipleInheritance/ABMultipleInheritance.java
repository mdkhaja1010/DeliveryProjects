package multipleInheritance;

public class ABMultipleInheritance {
	public static void main(String[] args) {
		AB ab=new AB();
		ab.Adisplay();
		ab.Bdisplay();
	}

}
