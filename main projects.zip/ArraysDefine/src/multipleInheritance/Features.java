package multipleInheritance;

public interface Features {
	void dailing();
	void messaging();
	
	public static void dualSim() {
		System.out.println("Feature phone supports dual sim");
	}
	public static void memoryCard() {
		System.out.println("Feature phone supports memory card");
	}
	

}
