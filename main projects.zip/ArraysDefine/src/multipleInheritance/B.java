package multipleInheritance;

public interface B {
	void Bdisplay();
}
