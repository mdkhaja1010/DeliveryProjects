package Interface;

public class ClassMainMulIn {
	public static void main(String[] args) {
		Dog dog=new Dog();
		dog.sleep();
		dog.eat();
		dog.copy();
		Laptop.audio();
		Laptop.commoncode();
		Laptop.security();
		
	}

}
