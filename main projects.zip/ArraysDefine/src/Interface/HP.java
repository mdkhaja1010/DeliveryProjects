package Interface;

public class HP implements Laptop{

	public void copy() {
		System.out.println("hp copy code");
		
	}

	
	public void paste() {
		System.out.println("hp paste code");
		
	}

	public void cut() {
		System.out.println("hp cut code");
	
	}	
			
	public void keyboard() {
		System.out.println("hp keyboard code");
		
		
	}
	public void printing() {
		System.out.println("hp printing code");
	}

}
