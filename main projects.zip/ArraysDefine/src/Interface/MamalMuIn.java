package Interface;

public interface MamalMuIn {
    void eat();

}

