package Interface;

public class Dog implements AnimalMulIn, MamalMuIn, Laptop {
	public void sleep() {
		System.out.println("the animal is sleeping");
	}
     public void eat() {
    	 System.out.println("the dog is eating");
     } 
     public void copy() {
 		System.out.println("hp copy code");
 		
 	}

 	
 	public void paste() {
 		System.out.println("hp paste code");
 		
 	}

 	public void cut() {
 		System.out.println("hp cut code");
 	
 	}	
 			
 	public void keyboard() {
 		System.out.println("hp keyboard code");
 		
 		
 	}
 	public void printing() {
 		System.out.println("hp printing code");
 	}
     
}

