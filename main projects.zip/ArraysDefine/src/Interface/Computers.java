package Interface;

public interface Computers {
	public void run();
	
	static void run1() {
		System.out.println("the number of threads is created");
	}
	

}
