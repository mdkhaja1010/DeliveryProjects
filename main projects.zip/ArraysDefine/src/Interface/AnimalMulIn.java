package Interface;

public interface AnimalMulIn {
	void sleep();

}
