package stringPrograms;

public class FullStopSeperate {
	
	public static void main(String[] args) {
		String name="my name is khaja.Iam 27 years old.I'm living in Hyderabad";
		String num[] = name.split("\\.");
        for (int i = 0; i < num.length; i++) {
            System.out.print(num[i]);
            if (i < num.length - 1) {
                System.out.print("-");
            }
           
        }
	}

}
