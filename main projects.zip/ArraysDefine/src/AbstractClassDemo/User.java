package AbstractClassDemo;

public class User {

	public static void main(String[] args) {
		Lenovo lenovo=new Lenovo();
		lenovo.copy();
		lenovo.paste();
		
		
		
       HP hp=new HP();
       hp.printing();
	}

}
