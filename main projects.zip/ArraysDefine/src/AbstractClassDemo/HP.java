package AbstractClassDemo;

public class HP extends SampleAbstractClass{

	
	public void cut() {
		System.out.println("hp cut code");
		
	}

	
	public void keyboard() {
	   System.out.println("hp keyboard code");
		
	}
	public void printing() {//this is new method
		System.out.println("hp printing code");
	}


}
