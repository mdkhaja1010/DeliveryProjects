package AbstractClassDemo;

public class Lenovo extends SampleAbstractClass {

	@Override
	public void cut() {
		System.out.println("cut code");
		
	}

	@Override
	public void keyboard() {
		System.out.println("keyboard code");
		
	}
	

}
