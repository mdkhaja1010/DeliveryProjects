package com.Enums;

public enum Values {
    min,
    max;
}
