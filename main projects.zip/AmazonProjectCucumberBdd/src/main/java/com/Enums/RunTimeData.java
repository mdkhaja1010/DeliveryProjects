package com.Enums;

public enum RunTimeData {

    TITLE;
}
