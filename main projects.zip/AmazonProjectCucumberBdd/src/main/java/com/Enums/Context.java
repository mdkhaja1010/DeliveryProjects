package com.Enums;

public enum Context {
PRICE
}
