package com.Enums;

public enum ExecutionType {
    LOCAL,
    REMOTE
}
