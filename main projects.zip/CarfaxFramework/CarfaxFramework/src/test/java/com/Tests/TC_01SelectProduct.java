package com.Tests;

import org.testng.annotations.Test;

import com.BaseClass.BaseTest;

public class TC_01SelectProduct extends BaseTest {

	
	
	
	@Test
	public void selectProductTest() throws InterruptedException
	{
		productSelection.clickOnFindCar();
		productSelection.clickOnClose();
		productSelection.clickOnCar();
		productSelection.verifyPrice();
	}
	
	
	
	
	
}
