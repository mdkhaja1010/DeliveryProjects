package com.Pom;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import com.BaseClass.BaseTest;
import com.Utils.ValidationUtility;
import com.Utils.WebDriverUtility;

public class ProductSelection extends BaseTest{

	public WebDriver driver;
	public String strExpectedText;
	

	public ProductSelection(WebDriver driver) {
		this.driver = driver;
		PageFactory.initElements(driver, this);

	}

	@FindBy(css = "#findCarText")
	public WebElement findCars;

	@FindBy(xpath = "//span[contains(@class,'closeLocIcon')]")
	public WebElement closeBtn;

	@FindBy(css  = "[data-carname-id=\"carname\"]")
	public WebElement selectCar;

	@FindBy(css = "[class=\"rupee-lac slprice\"]")
	public WebElement cartPrice;
	
	@FindBy(xpath  = "//div[contains(@class,'o-cpnu')]")
	public WebElement price;

	
	public void clickOnFindCar() {
		findCars.click();
	}
	public void clickOnClose() throws InterruptedException {
//		wLib.elementToBeClickable(3000, closeBtn);
		closeBtn.click();
	}	
	public void clickOnCar() throws InterruptedException {
		
		strExpectedText=cartPrice.getText();
		wLib.scrollBy();
		Thread.sleep(5000);
		selectCar.click();
		Thread.sleep(5000);
	}
	
	public void verifyPrice()
	{
		utilValidate.validation(strExpectedText, cartPrice);
		
	}
	

	

}
