package com.BaseClass;

import java.util.Properties;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.edge.EdgeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.safari.SafariDriver;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import com.Pom.ProductSelection;
import com.Utils.LogUtility;
import com.Utils.PropertyFileUtility;
import com.Utils.ValidationUtility;
import com.Utils.WebDriverUtility;

import io.github.bonigarcia.wdm.WebDriverManager;

public class BaseTest {

	public static WebDriver driver;
	public WebDriverUtility wLib = new WebDriverUtility(driver);
	public PropertyFileUtility propUtil = new PropertyFileUtility();
	public ProductSelection productSelection;
	public ValidationUtility utilValidate=new ValidationUtility();
	public LogUtility logUtil = new LogUtility();
	public Properties prop = new Properties();
	


	@BeforeMethod
	public void pageObjects()
	{
		productSelection=new ProductSelection(driver);
	}

	@BeforeClass
	public void launchbrowser() {
		String browser = propUtil.getBrowser();
		String Url = propUtil.getUrl();

		switch (browser) {
		case "chrome":
			chromeDriver();
			break;
		case "edge":
			edgeDriver();
			break;
		case "firefox":
			firefoxDriver();
			break;
		case "safari":
			safaridriver();
			break;
		default:
			System.out.println("select correct browser");
		}
		logUtil.info(browser + "browser launched successfully");
		getUrl(Url);
		wLib = new WebDriverUtility(driver);
		wLib.maximiseWindow();
		logUtil.info("successfully navigated to " + Url + " Url");

	}

	private void getUrl(String url) {
		driver.get(url);


	}

	private void edgeDriver() {
		WebDriverManager.edgedriver().setup();
		driver = new EdgeDriver();

	}

	private void safaridriver() {
		WebDriverManager.safaridriver().setup();
		driver = new SafariDriver();

	}

	private void chromeDriver() {
		ChromeOptions opt=new ChromeOptions();
		opt.addArguments("--disable-notifications");
		WebDriverManager.chromedriver().setup();
		driver = new ChromeDriver(opt);

	}

	public void firefoxDriver() {
		WebDriverManager.firefoxdriver().setup();
		driver = new FirefoxDriver();
	}
//	@AfterClass
//	public void tearDown()
//	{
//		driver.quit();
//	}


}
