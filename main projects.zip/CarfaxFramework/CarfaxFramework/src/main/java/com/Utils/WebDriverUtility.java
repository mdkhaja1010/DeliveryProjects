package com.Utils;

import java.time.Duration;
import java.util.Set;

import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

public class WebDriverUtility {
	
	WebDriver driver;
	WebDriverWait wait;
	JavascriptExecutor js;
	
	public WebDriverUtility(WebDriver driver)
	{
		this.driver=driver;
	}
	
	public void maximiseWindow() {
		driver.manage().window().maximize();
	}
	
	public void elementToBeClickable(int time, WebElement element) {
		wait = new WebDriverWait(driver, time);
		wait.until(ExpectedConditions.elementToBeClickable(element));
	}
	
	public String getElementtext(WebElement element) {
		
		return element.getText();
	}
	
	public void clickElement(WebElement element) {
		element.click();
	}
	
	public void sendText(WebElement element, String text) {
		element.sendKeys(text);
	}
	public void scrollBy()
	{
		js=(JavascriptExecutor)driver;
		js.executeScript("window.scrollBy(0,600)","");
	}
	
	public String getCurrentWindowTitle() {
		return driver.getTitle();
	}
	
	public String getCurrentWindowUrl() {
		return driver.getCurrentUrl();
	}
	
	public Set<String> getAllWindows(){
		
		return driver.getWindowHandles();
	}
	
	public void windowHandles(String windowTitle) {
		
		for (String win : getAllWindows()) {
			for (int i=0; i < getAllWindows().size(); i++) {
				
				String currentWindowTitle = driver.switchTo().window(win).getTitle();
				
				if (currentWindowTitle.equals(windowTitle)) {
					
					break;
				}
			}
		}
	}

}
