package com.Utils;

import java.util.logging.LogManager;

import org.testng.log4testng.Logger;



public class LogUtility {
	
	Logger logger = Logger.getLogger(LogUtility.class);
	 
	public void info(String message) {
		logger.info(message);
	}
	public void error(String message) {
		logger.error(message);
	}

	public void trace(String message) {
		logger.trace(message);
	}

	public void warn(String message) {
		logger.warn(message);
	}

}
