package com.Utils;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.Properties;

public class PropertyFileUtility {

	FileInputStream fis;
	public Properties pObj;

	public PropertyFileUtility() {

		try {
			fis = new FileInputStream(ConstantUtility.Propertfilepath);
			pObj = new Properties();
			try {
				pObj.load(fis);
			} catch (IOException e) {
				e.printStackTrace();
			}
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		}

	}

	public String getBrowser() {
		return pObj.getProperty("Browser");
	}

	public String getUrl() {
		return pObj.getProperty("Url");
	}

}
