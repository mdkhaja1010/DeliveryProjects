package com.Utils;

public interface ConstantUtility {
	
	String Propertfilepath = "C:\\Selenium\\CarfaxFramework\\src\\main\\resources\\test.properties";
	

}
