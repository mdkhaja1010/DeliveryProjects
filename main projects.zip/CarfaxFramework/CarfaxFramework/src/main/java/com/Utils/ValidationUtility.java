package com.Utils;

import org.openqa.selenium.WebElement;
import org.testng.Assert;

public class ValidationUtility {
	
	public void validation(String expected, WebElement element) {
		String actual = getText(element);
		String expect = expected;
		if(actual.contains(expect)) {
			assertionTrue(true);
		}else {
			assertionTrue(false);
		}
	}

	public void assertionTrue(boolean value) {
		Assert.assertTrue(value);
	}
	
	public String getText(WebElement element) {
		return element.getText();
	}
}
