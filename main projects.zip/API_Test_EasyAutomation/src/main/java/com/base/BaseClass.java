package com.base;

import org.openqa.selenium.Capabilities;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.edge.EdgeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.remote.RemoteWebDriver;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeMethod;

import com.pagefactory.AddRequestpage;
import com.pagefactory.CreatingAUTPage;
import com.pagefactory.TestSuitsPage;
import com.utils.CreateLog;
import com.utils.DateTime;
import com.utils.PropertyFile;
import com.utils.ReadExcelFile;
import com.utils.UtillFunctions;
import com.utils.Validations;

import io.github.bonigarcia.wdm.WebDriverManager;

public class BaseClass {
	public static WebDriver driver;
	public PropertyFile propertyfile=new PropertyFile();
	public UtillFunctions utilfunctions=new UtillFunctions(driver);
	public Validations validations=new Validations();
	public ReadExcelFile readexcel=new ReadExcelFile();
	public String url=propertyfile.getApplicationUrl();
	String browser=propertyfile.getApplicationBrowser();
	public CreateLog log=new CreateLog();
	public DateTime datetime= new DateTime();
	public CreatingAUTPage autpage;
	public TestSuitsPage testsuite;
	public DateTime dateTime=new DateTime();
	public AddRequestpage addrequest;
	@BeforeClass
	public void setup() {
		switch (browser) {
		case "chrome":
			chromeBrowser();
			break;
		case "firefox":
			firefoxBrowser();
			break;
		case "edge":
			edgeBrowser();
			break;
		default:
			error();
		}
	}
	@BeforeMethod
	public void launching() {
		autpage=new CreatingAUTPage(driver);
		testsuite=new TestSuitsPage(driver);
		addrequest=new AddRequestpage(driver);
		
	}

	/*
	 * @AfterClass public void tearDown() { driver.quit();
	 * log.info("Browser closed"); }
	 */
	public void chromeBrowser() {
		WebDriverManager.chromedriver().setup();
		driver = new ChromeDriver();
		log.info("ChromeBrowser is launched");
		url();
	}

	public void firefoxBrowser() {
		WebDriverManager.firefoxdriver().setup();
		driver = new FirefoxDriver();
		log.info("firefoxBrowser is launched");
		url();
	}

	public void edgeBrowser() {
		WebDriverManager.edgedriver().setup();
		driver = new EdgeDriver();
		url();
		log.info("edge browser is launched");
	}

	public void error() {
		System.err.println("unknown Browser");
		log.info("unknown Browser");
	}

	
	public void url() {
		driver.get(url);
		log.info("Sauce labs url launched");
		driver.manage().window().maximize();
		log.info("window is maximezed");

	}
	public void maximizeBrowser() {
		utilfunctions.maximizeWindow();
	}

	public String browserName() {
		Capabilities cap = ((RemoteWebDriver) driver).getCapabilities();
		String browsername = cap.getBrowserName().toLowerCase();
		return browsername;
	}

	public String browserversion() {
		Capabilities cap = ((RemoteWebDriver) driver).getCapabilities();
		String browserversion = cap.getBrowserVersion().toString();
		return browserversion;
	}

	
	

}
