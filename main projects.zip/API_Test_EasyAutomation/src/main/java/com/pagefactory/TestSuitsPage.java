package com.pagefactory;

import java.util.List;

import javax.swing.text.Utilities;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import com.base.BaseClass;
import com.utils.UtillFunctions;

public class TestSuitsPage extends BaseClass {
	WebDriver driver;

	public TestSuitsPage(WebDriver driver) {
		this.driver = driver;
		PageFactory.initElements(driver, this);
	}

	@FindBy(xpath = "//span[text()='Test Suites']")
	private WebElement testSuitbtn;
	@FindBy(xpath = "//div[@role='combobox']")
	private WebElement dropdown;
	// @FindBy(xpath="//ul[@class='MuiList-root MuiList-padding MuiMenu-list
	// css-r8u8y9']")
	// private List<WebElement> dropdownlist;
	@FindBy(css = "[class*='MuiButtonBase-root MuiMenuItem-root MuiMenuItem-gutters']")
	public List<WebElement> dropdownlist;
	@FindBy(xpath = "//*[local-name()='svg'][@data-testid='AddIcon']")
	private WebElement clkCreateTestSuite;
	@FindBy(css = "input[name='name']")
	private WebElement testName;
	@FindBy(css = "textarea[name='description']")
	private WebElement testDescription;
	@FindBy(xpath = "(//div[@role='combobox'])[1]")
	private WebElement protocolsclk;
	@FindBy(xpath = "(//li[@role='option'])[1]")
	private WebElement protocols;
	@FindBy(xpath = "//*[@name='baseURL']")
	private WebElement baseurl;
	@FindBy(xpath="(//input[@type='checkbox'])[2]")
	private WebElement checkboxele;
	
	
	//@FindBy(css="[class*='containedSizeSmall css-1']")
	@FindBy(xpath="//button[@type='submit']")
	private WebElement createSuitebtn;
	@FindBy(css="[class='DBListMain MuiBox-root css-0'] [class='MuiGrid-root MuiGrid-container MuiGrid-item css-n6nfem']")
	private WebElement suitebtn;

	public void clkTestSuit() throws InterruptedException {
		utilfunctions.ClickOnElement(testSuitbtn);
		Thread.sleep(3000);
	}

	public void selectDropdown() throws InterruptedException {
		utilfunctions.ClickOnElement(dropdown);
	}

	public void selectdropdownvalue() {
		try {
			Thread.sleep(5000);
		} catch (Exception e) {
		}
		for (int i = 0; i < dropdownlist.size(); i++) {
			if (dropdownlist.get(i).getText().equalsIgnoreCase(CreatingAUTPage.Autname)) {
				System.out.println(dropdownlist.get(i).getText());
				dropdownlist.get(i).click();
			}
		}

	}

	public void clickCreateTestSuite() {
		utilfunctions.explicitWaitToVisibilityOfElement(10, clkCreateTestSuite);
		utilfunctions.ClickOnElement(clkCreateTestSuite);
	}

	public void testsuitname() {
		utilfunctions.sendText(testName, "TestingDemo");
	}

	public void testsuitdesc() {
		utilfunctions.sendText(testDescription, "TestingDemo123");
	}

	public void clkprotocoldropdown() {
		utilfunctions.ClickOnElement(protocolsclk);
	}

	public void selectingprotocol() {

		// utilfunctions.ClickOnElement(protocolsclk);
		try {
			Thread.sleep(3000);
			utilfunctions.ClickOnElement(protocols);

		} catch (Exception e) {
		}

	}

	public void enteringurl() {
		utilfunctions.sendText(baseurl, "simple-books-api.glitch.me");
	}
	public void checkbox() {
		utilfunctions.ClickOnElement(checkboxele);
		try {
			Thread.sleep(5000);
		}
		catch (Exception e){
			
		}
	}
	public void clkcreatesuitebtn() {
		utilfunctions.moveToElement(createSuitebtn);
		
				createSuitebtn.click();
				try {
					Thread.sleep(4000);
				}catch(Exception e){
					
				}
		//utilfunctions.ClickOnElement(createSuitebtn);
	}
	public void opensuitebtn() {
		utilfunctions.ClickOnElement(suitebtn);
	}

	// [class*='createRequest MuiBox-root'] [id='mui-component-select-method']
	//[class*='MuiButtonBase-root MuiMenuItem-root MuiMenuItem-gutters']
}
