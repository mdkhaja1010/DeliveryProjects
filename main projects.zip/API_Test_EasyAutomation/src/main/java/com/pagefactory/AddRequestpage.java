package com.pagefactory;

import java.awt.AWTException;
import java.awt.Robot;
import java.util.List;

import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import com.base.BaseClass;

public class AddRequestpage extends BaseClass {
	WebDriver driver;

	public AddRequestpage(WebDriver driver) {
		this.driver = driver;
		PageFactory.initElements(driver, this);
	}

	@FindBy(xpath = "//*[local-name()='svg'][@data-testid='AddCircleOutlineIcon']")
	private WebElement addRequest;
	@FindBy(xpath = "//*[@name='name']")
	private WebElement requestName;
	@FindBy(xpath = "(//*[@id='mui-component-select-method'])[2]")
	private WebElement selectingrequest;
	@FindBy(xpath = "//li[@role='option']")
	private List<WebElement> requestDropdown;
	@FindBy(xpath = "//input[@placeholder='Value']")
	private WebElement urlsection;
	@FindBy(xpath = "//li[text()='GlobalUrl']")
	private WebElement globalUrl;
	@FindBy(xpath = "(//input[@placeholder='Value'])[2]")
	private WebElement pathfield;
	@FindBy(xpath = "(//div[@aria-haspopup='listbox'])[4]")
	private WebElement authorization;
	@FindBy(css = "[class*='MuiButtonBase-root MuiMenuItem-root MuiMenuItem-gutters MuiMenuItem-root MuiMenuItem-gutters']")
	private List<WebElement> autoriztionselection;
	@FindBy(xpath = "//textarea[@placeholder='Value']")
	private WebElement tokenvalue;
	@FindBy(xpath = "//li[text()='GlobalAccess']")
	private WebElement selectiongolbalaccess;
	@FindBy(css = "[class*='MuiButtonBase-root MuiTab-root MuiTab-textColorPrimary']")
	private List<WebElement> clkrequest;
	@FindBy(css = "input[value='raw']")
	private WebElement clkrawdata;
	@FindBy(css = "*[id='codeArea']")
	private WebElement sendingreqestdata;
	public String book = "bookId";
	public int booking = 3;
	public String name = "customerName";
	public String cusName = "John";
	@FindBy(xpath = "//*[text()='Save']")
	private WebElement savebtn;
	@FindBy(xpath = "//*[text()='Send']")
	private WebElement sendingrequest;
	@FindBy(xpath = "//button[text()='Text']")
	private WebElement resultsText;
	@FindBy(css = "[class*='MuiButtonBase-root MuiTab-root MuiTab-textColorPrimary']")
	private List<WebElement> response;
	@FindBy(xpath="//*[local-name()='svg'] [@data-testid='CancelOutlinedIcon']")
	private WebElement closeresponse;
	

	public void clkcreateRequest() {
		utilfunctions.ClickOnElement(addRequest);
		try {
			Thread.sleep(5000);
		} catch (Exception e) {

		}
	}

	public void renameRequest() throws AWTException {
		utilfunctions.ClickOnElement(requestName);
		try {
			Thread.sleep(3000);
		} catch (Exception e) {

		}

//	       requestName.clear();
//	       requestName.clear();
		requestName.sendKeys(Keys.CONTROL, "a");
		requestName.sendKeys(Keys.DELETE);

		try {
			Thread.sleep(3000);
		} catch (Exception e) {

		}

		requestName.sendKeys("CreatingNewOrder");
		try {
			Thread.sleep(3000);
		} catch (Exception e) {

		}
		// requestName.clear();

		/*
		 * Actions act=new Actions(driver); act.doubleClick(requestName);
		 * //requestName.click(); requestName.clear();
		 */
	}

	public void selectingrequestclk() {
		utilfunctions.ClickOnElement(selectingrequest);
		try {
			Thread.sleep(3000);
		} catch (Exception e) {
		}
	}

	public void selectPostRequest() {
		for (int i = 0; i < requestDropdown.size(); i++) {
			if (requestDropdown.get(i).getText().equalsIgnoreCase("POST")) {
				requestDropdown.get(i).click();
			}
		}
		try {
			Thread.sleep(3000);
		} catch (Exception e) {
		}
	}

	public void urlenteringfield() {
		urlsection.sendKeys(Keys.CONTROL, "a");
		urlsection.sendKeys(Keys.DELETE);
		// urlsection.clear();
		try {
			Thread.sleep(3000);
		} catch (Exception e) {
		}
		urlsection.sendKeys("{{");
		try {
			Thread.sleep(3000);
		} catch (Exception e) {
		}
		utilfunctions.ClickOnElement(globalUrl);

	}

	public void enteringpathurl() {
		try {
			Thread.sleep(3000);
		} catch (Exception e) {
		}
		utilfunctions.sendText(pathfield, "orders");

	}

	public void provideauthorization() {
		utilfunctions.ClickOnElement(authorization);
		try {
			Thread.sleep(3000);
		} catch (Exception e) {
		}
	}

	public void selectingautorizationbt() {
		for (int i = 0; i < autoriztionselection.size(); i++) {
			if (autoriztionselection.get(i).getText().equalsIgnoreCase("Bearer Token")) {
				autoriztionselection.get(i).click();
			}
		}
		try {
			Thread.sleep(3000);
		} catch (Exception e) {
		}

	}

	public void enteringtoken() {
		utilfunctions.sendText(tokenvalue, "{{");
		try {
			Thread.sleep(3000);
		} catch (Exception e) {
		}

	}

	public void selectinglobaltoken() {
		utilfunctions.ClickOnElement(selectiongolbalaccess);
		try {
			Thread.sleep(3000);
		} catch (Exception e) {
		}
	}

	public void selectingrequestbtn() {
		for (int i = 0; i < clkrequest.size(); i++) {
			if (clkrequest.get(i).getText().equalsIgnoreCase("Request")) {
				clkrequest.get(i).click();
			}
		}
		try {
			Thread.sleep(3000);
		} catch (Exception e) {
		}

	}

	public void rawbuton() {
		utilfunctions.ClickOnElement(clkrawdata);
		try {
			Thread.sleep(3000);
		} catch (Exception e) {
		}
	}

	public void sendingdatajson() {
		sendingreqestdata.sendKeys(Keys.CONTROL, "a");
		sendingreqestdata.sendKeys(Keys.DELETE);
		try {
			Thread.sleep(3000);
		} catch (Exception e) {
		}
		utilfunctions.sendText(sendingreqestdata, "{" + "\"" + book + "\"" + ":" + booking + "," + "\"" + name + "\""
				+ ":" + "\"" + cusName + "\"" + "}");
	}

	public void savingrequest() {
		utilfunctions.ClickOnElement(savebtn);

	}

	public void sendingrequest() {
		utilfunctions.ClickOnElement(sendingrequest);
		try {
			Thread.sleep(6000);
		} catch (Exception e) {
		}
		
	}

	public void clktext() {
		utilfunctions.ClickOnElement(resultsText);
		try {
			Thread.sleep(3000);
		} catch (Exception e) {
		}
	}

	public void cookiesResponse() {
		for (int i = 0; i < response.size(); i++) {
			if (response.get(i).getText().equalsIgnoreCase("Cookies")) {
				response.get(i).click();
			}
		}
		try {
			Thread.sleep(3000);
		} catch (Exception e) {
		}

	}

	public void headersResponse() {
		for (int i = 0; i < response.size(); i++) {
			if (response.get(i).getText().equalsIgnoreCase("Headers (6)")) {
				response.get(i).click();
			}
		}
		try {
			Thread.sleep(3000);
		} catch (Exception e) {
		}

	}

	public void testResultsResponse() {
		for (int i = 0; i < response.size(); i++) {
			if (response.get(i).getText().equalsIgnoreCase("Test Results")) {
				response.get(i).click();
			}
		}
		try {
			Thread.sleep(3000);
		} catch (Exception e) {
		}
	}
	public void closeresponsebutton() {
		utilfunctions.ClickOnElement(closeresponse);
		
	}

}
