package com.pagefactory;

import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import com.base.BaseClass;

public class CreatingAUTPage extends BaseClass{

	
   WebDriver driver;
   public CreatingAUTPage(WebDriver driver) {
	   this.driver=driver;
	   PageFactory.initElements(driver, this);
   }
  static String Autname;
   @FindBy(xpath="//div[@class='MuiFormControl-root css-13sljp9']")
   private WebElement clkCrateAut;
   @FindBy(xpath="//input[@name='name']")
   private WebElement name;
   @FindBy(xpath="//textarea[@name='description']")
   private WebElement description;
   @FindBy(xpath="//button[contains(@class, 'MuiButton-containedPrimary') and contains(@class, 'MuiButton-sizeSmall') and contains(@class, 'MuiButton-containedSizeSmall') and @type='submit' and text()='Create']\r\n")
   private WebElement createAut;
   String autname;
   public void clkCreateAutbtn() throws Throwable {
	   utilfunctions.ClickOnElement(clkCrateAut);
	   Thread.sleep(4000);
	   
   }
   
   public void enterAutName() {
	  String strautName="testingDemo2"+datetime.randomNumber();
	  Autname=strautName;
	  System.out.println("$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$ "+Autname+" ################");
	   utilfunctions.sendText(name, strautName);
   }
   public void enterDescription() throws Throwable {
	   utilfunctions.sendText(description, "WelcomeToAPITestEasy");
	   Thread.sleep(3000);
	   
   }
   public void creatingAUTbtn1() {
	   
	   try {
		   utilfunctions.ClickOnElement(createAut);
		  } catch (Exception e) {
		     JavascriptExecutor executor = (JavascriptExecutor) driver;
		     executor.executeScript("arguments[0].click();", createAut);
		  }
	  
	  // utilfunctions.ClickOnElement(createAut);
	   
   }
}
