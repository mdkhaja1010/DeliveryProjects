package com.TestRunner;

import java.time.Duration;
import java.util.List;
import java.util.concurrent.TimeoutException;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import freemarker.core.JavaScriptOutputFormat;

public class GoibiboApp {

	public static void main(String[] args) throws InterruptedException {
		WebDriver driver = new ChromeDriver();
		driver.manage().window().maximize();
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(10));
		driver.get("https://www.goibibo.com/");
		Thread.sleep(3000);
		driver.findElement(
				By.xpath("//div[@class='sc-lcIPJg gjkfnn']//div[2]//div//div//div[2]//span[@class='sc-gsFSXq bGTcbn']"))
				.click();
		WebElement arrival = driver.findElement(
				By.xpath("//div[@class='sc-12foipm-16 wRKJm fswFld ']//p[normalize-space()='Enter city or airport']"));
		Actions act = new Actions(driver);
		act.moveToElement(arrival).click().sendKeys("Vijaya").perform();
		Thread.sleep(3000);
		WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(10));
		List<WebElement> ele = driver.findElements(By.xpath(
				"//li[@role='presentation']//span//following-sibling::div//p//span[@class='autoCompleteTitle ']"));
		Thread.sleep(3000);
		try {
			ele = driver.findElements(By.xpath(
					"//li[@role='presentation']//span//following-sibling::div//p//span[@class='autoCompleteTitle ']"));
			for (int i = 0; i < ele.size(); i++) {
				System.out.println(ele.get(i).getText());
				if (ele.get(i).getText().contains("Vijayawada, India")) {
					// wait.until(ExpectedConditions.refreshed(ExpectedConditions.elementToBeClickable(ele.get(i))));
					ele.get(i).click();
					break;
				}

			}
		} catch (Exception e) {
			System.out.println("the element is more time to visible " + e.getMessage());
		}
		Thread.sleep(3000);
		WebElement destination = driver.findElement(By.xpath("//input[@type='text']"));
		destination.sendKeys("Delhi");
		Thread.sleep(3000);
		List<WebElement> ele1 = driver.findElements(By.xpath(
				"//li[@role='presentation']//span//following-sibling::div//p//span[@class='autoCompleteTitle ']"));
		// Thread.sleep(3000);
		try {
			for (int i = 0; i < ele1.size(); i++) {
				System.out.println(ele1.get(i).getText());
				if (ele1.get(i).getText().contains("Jaipur, India")) {
					ele1.get(i).click();
					break;
				}

			}
		} catch (Exception e) {
			System.out.println("the element is not found " + e.getLocalizedMessage());
		}
		Thread.sleep(3000);
		WebElement calendericon = driver.findElement(By.xpath(
				"//div[@class='sc-12foipm-34 iHoHRr']//div//span//following-sibling::p//span[contains(@class,'fswDownArrow')]"));
		calendericon.click();
		Thread.sleep(3000);
		WebElement monthselection = driver.findElement(By.xpath("//div[@class='DayPicker-Caption']//div"));
		WebElement nextmonthIcon = driver.findElement(By.xpath("//span[@aria-label='Next Month']"));
		String desiredmonth = "October 2024";
		while (true) {
			String monthname = monthselection.getText();
			System.out.println(monthname);
			if (monthname.equals(desiredmonth)) {
				break;
			} else {
				nextmonthIcon.click();
			}
		}
		String desiredday = "10";
		Thread.sleep(4000);
		List<WebElement> datafetching = driver
				.findElements(By.xpath("//div[@class='DayPicker-Day']//p[@class='fsw__date']"));
		Thread.sleep(4000);
		for (int i = 0; i < datafetching.size(); i++) {
			if (datafetching.get(i).getText().equals(desiredday)) {
				datafetching.get(i).click();
				break;

			}
		}
		driver.findElement(
				By.xpath("//p[contains(@class,'fswWidgetTitle')]//span[contains(@class,'fswDownArrowTraveller')]"))
				.click();
		Thread.sleep(2000);
		driver.findElement(By.xpath("//a[text()='Done']")).click();
		driver.findElement(By.xpath("//span[text()='SEARCH FLIGHTS']")).click();
		driver.quit();
	}                                             
}
