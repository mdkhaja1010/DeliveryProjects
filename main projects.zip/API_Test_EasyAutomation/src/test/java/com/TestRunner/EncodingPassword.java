package com.TestRunner;

import java.util.Base64;

public class EncodingPassword {

	public static void main(String[] args) {
		String password="Kh@ja1997";
	byte[] encrypt=Base64.getEncoder().encode(password.getBytes());
	System.out.println("the encrypted password is "+ new String(encrypt));
	byte[] decrypt=Base64.getDecoder().decode(encrypt);
	System.out.println("the decrypted password is "+ new String(decrypt));

	}

}
