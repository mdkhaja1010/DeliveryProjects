package com.TestRunner;

import java.awt.AWTException;
import java.awt.Robot;
import java.awt.Toolkit;
import java.awt.datatransfer.StringSelection;
import java.awt.event.KeyEvent;
import java.time.Duration;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.edge.EdgeDriver;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.annotations.Test;

import io.github.bonigarcia.wdm.WebDriverManager;

public class FileUpload1 {
	@Test
	public void uploading_file() throws InterruptedException, AWTException {
		WebDriverManager.chromedriver().setup();
		ChromeDriver driver = new ChromeDriver();
		driver.get("https://west-wind.com/wconnect/wcscripts/fileupload.wwd");
		driver.manage().window().maximize();
		WebElement ele =driver.findElement(By.xpath("//div[@class='container sample']/following-sibling::div/form/div"));
		//JavascriptExecutor jsp= (JavascriptExecutor) driver;
		//jsp.executeAsyncScript("arguments[0].scrollIntoView(true);", ele);
		//WebDriverWait wait =new WebDriverWait(driver, Duration.ofSeconds(10));
		//wait.until(ExpectedConditions.elementToBeClickable(ele));
		ele.click();
//		Thread.sleep(4000);
//		String filePath = "D:\\JMeterIntroCertificate.PNG";
//		String script = "arguments[0].setAttribute('value', arguments[1])";
//		((JavascriptExecutor) driver).executeScript(script, ele, filePath);
		
		
		Thread.sleep(5000);
		Robot robot = new Robot();
		StringSelection str = new StringSelection("D:\\JMeterIntroCertificate.PNG");
		Toolkit.getDefaultToolkit().getSystemClipboard().setContents(str, str);
		robot.keyPress(KeyEvent.VK_CONTROL);
		robot.keyPress(KeyEvent.VK_V);
		Thread.sleep(5000);
		robot.keyRelease(KeyEvent.VK_CONTROL);
		robot.keyRelease(KeyEvent.VK_V);
		Thread.sleep(5000);
		robot.keyPress(KeyEvent.VK_ENTER);
		robot.keyRelease(KeyEvent.VK_ENTER);
		Thread.sleep(2000);

		//ele.sendKeys("");
		//We
		
       
}
}
