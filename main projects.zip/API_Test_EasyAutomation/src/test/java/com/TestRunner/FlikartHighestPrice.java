package com.TestRunner;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.Test;

import io.github.bonigarcia.wdm.WebDriverManager;

public class FlikartHighestPrice {

	@Test
	public void setupborowser() throws InterruptedException {
		WebDriverManager.chromedriver().setup();
		WebDriver driver= new ChromeDriver();
		driver.manage().window().maximize();
		driver.get("https://www.flipkart.com/");
		WebElement ele=driver.findElement(By.name("q"));
		ele.sendKeys("iphone",Keys.ENTER);
		Thread.sleep(4000);
		List<WebElement> eleprice=driver.findElements(By.xpath("//div[@class='col col-5-12 nlI3QM']//div//div//div[@class='_30jeq3 _1_WHN1']"));
		double higestprice=0.0;
		String hightestPriceString="";
		for(WebElement pricElement:eleprice) {
			String priceString=pricElement.getText().replaceAll("[^\\d.]", "");
			double price=Double.parseDouble(priceString);
			if(price > higestprice) {
				higestprice=price;
				hightestPriceString=priceString;
				
			}
		}
		System.out.println("the highest price iphone in the flipkart page is:"+hightestPriceString);
		//driver.quit();
		
	}

}
