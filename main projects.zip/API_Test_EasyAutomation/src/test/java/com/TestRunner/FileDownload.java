package com.TestRunner;

import java.io.File;
import java.util.HashMap;
import java.util.Map;
import java.util.Random;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.edge.EdgeDriver;
import org.openqa.selenium.edge.EdgeOptions;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.annotations.Test;

import io.github.bonigarcia.wdm.WebDriverManager;

public class FileDownload {
	
	public int randomNumber()
	{
  
		Random rand=new Random();
		int randomInRange = rand.nextInt(100);
		return randomInRange;
	}


	  @Test
	  public void filedownload() throws Throwable {
		  WebDriverManager.chromedriver().setup();
		  ChromeOptions options = new ChromeOptions();
		  Map<String, Object> prefs= new HashMap<>();
		  prefs.put("download.default_directory","C:\\Users\\KhajaMohammed-Kairos\\Downloads");
		  options.setExperimentalOption("prefs", prefs);
		  ChromeDriver driver= new ChromeDriver(options);
		  driver.get("https://dlptest.com/sample-data/");
		  driver.manage().window().maximize();
		  Thread.sleep(5000);
		 // WebDriverWait wait = new WebDriverWait(driver, 10);
		  WebElement downloadlink= driver.findElement(By.xpath("//a[@rel='noopener']//strong[text()='XLSX File']"));
		  downloadlink.click();
		  try {
	            Thread.sleep(5000); 
	        } catch (InterruptedException e) {
	            e.printStackTrace();
	        }
	  
	  File downloadfile= new File("C:\\Users\\KhajaMohammed-Kairos\\Downloads\\sample-data.xlsx");
	  Thread.sleep(5000);
	 // wait.until(ExpectedConditions.visibilityOf((WebElement) downloadfile));
	  if(downloadfile.exists()) {
		  System.out.println("file download successfully");
	  }else {
		  System.out.println("file is not downloaded");
	  }
	  }
	  
}
