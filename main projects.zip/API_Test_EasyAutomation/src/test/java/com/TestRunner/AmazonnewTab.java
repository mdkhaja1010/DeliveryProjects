package com.TestRunner;

import java.io.IOException;

import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.edge.EdgeDriver;

import io.github.bonigarcia.wdm.WebDriverManager;

public class AmazonnewTab {

	public static void main(String[] args) throws Exception{
		//WebDriverManager.edgedriver().setup();
		//WebDriverManager.chromedriver().setup();
		WebDriver driver =new ChromeDriver();
		//WebDriver driver= new EdgeDriver();
		driver.manage().window().maximize();
		driver.get("https://www.amazon.in/");
		Thread.sleep(7000);
		String currentUrl = driver.getCurrentUrl();
		
		 ((JavascriptExecutor)driver).executeScript("window.open()");
	        
	        // Switch to the new tab
	        for (String handle : driver.getWindowHandles()) {
	            driver.switchTo().window(handle);
	        }
	        
	        // Paste the URL into the new tab
	        driver.get(currentUrl);
	        
	}

}
