	package com.TestRunner;


import org.testng.annotations.Test;

import com.base.BaseClass;
import com.utils.Validations;

public class TC_001API_TestEasyAUT extends BaseClass{
	//HomePage page=new HomePage(driver);
	@Test
	public void CreatingAutTestCase() throws Throwable 
	
	{
		autpage.clkCreateAutbtn();
		autpage.enterAutName();
		autpage.enterDescription();
		autpage.creatingAUTbtn1();
		testsuite.clkTestSuit();
		testsuite.selectDropdown();
		testsuite.selectdropdownvalue();
		testsuite.clickCreateTestSuite();
		testsuite.testsuitname();
		testsuite.testsuitdesc();
		testsuite.clkprotocoldropdown();
		testsuite.selectingprotocol();
		testsuite.enteringurl();
		testsuite.checkbox();
		testsuite.clkcreatesuitebtn();
		testsuite.opensuitebtn();
		addrequest.clkcreateRequest();
		addrequest.renameRequest();
		addrequest.selectingrequestclk();
		addrequest.selectPostRequest();
		addrequest.urlenteringfield();
		addrequest.enteringpathurl();
		addrequest.provideauthorization();
		addrequest.selectingautorizationbt();
		addrequest.enteringtoken();
		addrequest.selectinglobaltoken();
		addrequest.selectingrequestbtn();
		addrequest.rawbuton();
		addrequest.sendingdatajson();
		addrequest.savingrequest();
		addrequest.sendingrequest();
		addrequest.clktext();
		addrequest.cookiesResponse();
		addrequest.headersResponse();
		addrequest.testResultsResponse();
		addrequest.closeresponsebutton();
		
		
	}	
}
