package com.TestRunner;

import java.time.Duration;
import java.util.List;
import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.ExpectedCondition;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.annotations.Test;

import io.github.bonigarcia.wdm.WebDriverManager;

public class AmazonHighestPrice {
	@Test
	public void setupborowser() throws InterruptedException {
		//WebDriverManager.chromedriver().setup();
		WebDriver driver = new ChromeDriver();
		driver.manage().window().maximize();
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(10));
		//driver.get("https://www.amazon.in/");
		driver.get("https://www.croma.com/");
		Thread.sleep(5000);
		//driver.findElement(By.id("twotabsearchtextbox")).sendKeys("iphone", Keys.ENTER);
		driver.findElement(By.cssSelector("input#searchV2")).sendKeys("laptops", Keys.ENTER);
		int highestprice = 0;
		//WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(10));
		//Thread.sleep(3000);
		//List<WebElement> productElements = driver.findElements(By.xpath("//span[@class='a-price']//span[@class='a-price-whole']"));
		List<WebElement> productElements = driver.findElements(By.xpath("//div[@class='new-price plp-srp-new-price-cont']//span[@class='amount plp-srp-new-amount']"));
		//wait.until(ExpectedConditions.elementToBeSelected((WebElement) productElements));
		for (WebElement ele : productElements) {
			String price = ele.getText().replaceAll("[^\\d.]", "");
			System.out.println(price);
			int price1 = Integer.parseInt(price);
			if (price1 > highestprice) {
				highestprice = price1;
			}
		}
		System.out.println("the highest price iphone in the amzon page is:" + highestprice);
		// driver.quit();
	}
}