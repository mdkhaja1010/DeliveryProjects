package com.TestRunner;

import java.awt.AWTException;
import java.awt.Robot;
import java.awt.Toolkit;
import java.awt.datatransfer.StringSelection;
import java.awt.event.KeyEvent;
import java.time.Duration;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.edge.EdgeDriver;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.annotations.Test;

import io.github.bonigarcia.wdm.WebDriverManager;

public class FileUpload {
	//@Test
	/*
	 * public void fileupload() throws InterruptedException {
	 * WebDriverManager.edgedriver().setup(); EdgeDriver driver =new EdgeDriver();
	 * driver.get("https://cgi-lib.berkeley.edu/ex/fup.html");
	 * 
	 * driver.manage().window().maximize(); Thread.sleep(5000); Thread.sleep(5000);
	 * // WebDriverWait wait = new WebDriverWait(driver, 10); // WebElement
	 * passwordElement =
	 * wait.until(ExpectedConditions.elementToBeClickable(By.cssSelector("#Passwd"))
	 * ); WebElement ele
	 * =driver.findElement(By.xpath("//*[@type='file' and @name='upfile']"));
	 * //Actions act =new Actions(driver); //act.moveToElement(ele).perform();
	 * System.out.println(ele.isEnabled()); ele.click();
	 * ele.sendKeys("D:\\JMeterScripts\\Demo\\FileUpload\\Data\\demoTest.txt");
	 * 
	 * //driver.findElement(By.name("[name='upfile']")).sendKeys(
	 * "D:\\JMeterScripts\\Demo\\FileUpload\\Data\\demoTest.txt");
	 * 
	 * }
	 */
	//@Test
//	public void fileUpload() throws InterruptedException {
//		WebDriverManager.edgedriver().setup();
//		EdgeDriver driver = new EdgeDriver();
//		driver.get("https://cgi-lib.berkeley.edu/ex/fup.html");
//
//		driver.manage().window().maximize();
//
//		WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(20)); // Wait for up to 20 seconds
//
//		WebElement fileInput = wait
//				.until(ExpectedConditions.elementToBeClickable(By.xpath("//*[@type='file' and @name='upfile']")));
//		String filePath = "D:\\JMeterScripts\\Demo\\FileUpload\\Data\\demoTest.txt";
//
//		try {
//			fileInput.sendKeys(filePath);
//			System.out.println("File uploaded successfully.");
//		} catch (Exception e) {
//			System.err.println("Failed to upload file: " + e.getMessage());
//		} finally {
//			Thread.sleep(5000);
//			driver.quit(); // Quit the driver after use }
//		}


	@Test
	public void uploading_file() throws InterruptedException, AWTException {
		WebDriverManager.edgedriver().setup();
		EdgeDriver driver = new EdgeDriver();
		driver.get("https://cgi-lib.berkeley.edu/ex/fup.html");
		driver.manage().window().maximize();
		WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(20));
		WebElement fileInput = wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//*[@type='file' and @name='upfile']")));
		fileInput.click();
		Robot robot = new Robot();
		StringSelection str = new StringSelection("D:\\JMeterScripts\\Demo\\FileUpload\\Data\\demoTest.txt");
		Toolkit.getDefaultToolkit().getSystemClipboard().setContents(str, str);
		robot.keyPress(KeyEvent.VK_CONTROL);
		robot.keyPress(KeyEvent.VK_V);
		Thread.sleep(5000);
		robot.keyRelease(KeyEvent.VK_CONTROL);
		robot.keyRelease(KeyEvent.VK_V);
		Thread.sleep(5000);
		robot.keyPress(KeyEvent.VK_ENTER);
		robot.keyRelease(KeyEvent.VK_ENTER);
		Thread.sleep(2000);
	
}
}