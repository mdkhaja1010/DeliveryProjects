package com.TestRunner;

import java.time.Duration;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class ComparisonTwoPricesAmazon {

	public static void main(String[] args) throws InterruptedException {
		WebDriver driver = new ChromeDriver();
		driver.manage().window().maximize();
		driver.get("https://www.amazon.in/");
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(10));
		Thread.sleep(5000);
		driver.findElement(By.id("twotabsearchtextbox")).sendKeys("iphone", Keys.ENTER);
		List<WebElement> productElements = driver.findElements(By.xpath("//span[@class='a-price-whole']"));
		int firstprice=0;
		int secondprice=0;
		for(int i=0;i<2;i++) {
			String price =productElements.get(i).getText().replaceAll("[^\\d.]", "");
			int priceof=Integer.parseInt(price);
			if(i==0) {
				firstprice=priceof;
			}else if(i==1) {
				secondprice=priceof;
			}
			System.out.println(priceof);  
			
		}
		System.out.println(firstprice);
		System.out.println(secondprice);
		if(firstprice>secondprice) {
			productElements.get(0).click();
			
		}
		else {
			productElements.get(1).click();
			
		}
		
		
	}

}
