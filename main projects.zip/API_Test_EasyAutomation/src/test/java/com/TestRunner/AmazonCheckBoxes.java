package com.TestRunner;

import java.time.Duration;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.edge.EdgeDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.annotations.Test;

public class AmazonCheckBoxes {
	public static void main(String[] args) throws InterruptedException {

		WebDriver driver = new ChromeDriver();
		driver.manage().window().maximize();
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(10));
		driver.get("https://www.amazon.in/");
		Thread.sleep(3000);
		List<WebElement> list = driver.findElements(By.cssSelector("#nav-xshop-container [class*='nav-a']"));
		for (int i = 0; i < list.size(); i++) {
			if (list.get(i).getText().equals("Fashion")) {
				list.get(i).click();
				break;
			}
		}
		// System.out.println("click");
		// WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(30));

		List<WebElement> list1 = driver.findElements(By.cssSelector("[class='sl-sobe-carousel-sub-card-footer']"));
		// System.out.println("enter in list");
		for (int i = 0; i < list1.size(); i++) {
			if (list1.get(i).getText().contains("Men's Clothing")) {
				list1.get(i).click();
				break;
			}
		}
		List<WebElement> checkbox = driver.findElements(
				By.cssSelector("[class*='a-checkbox a-checkbox-fancy'] [class*='a-icon a-icon-checkbox']"));
		List<WebElement> checkboxText = driver
				.findElements(By.cssSelector("[class*='a-link-normal'] [class*='a-size-base a-color-base']"));
		for (int i = 0; i < checkboxText.size(); i++) {
			if (checkboxText.get(i).getText().equals("Premium Brands")) {
				checkbox.get(i).click();
				break;

			}

		}

	}
}
