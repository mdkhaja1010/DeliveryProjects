package com.TestRunner;

import java.util.ArrayList;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.edge.EdgeDriver;
import org.openqa.selenium.edge.EdgeOptions;
import org.testng.annotations.Test;

import io.github.bonigarcia.wdm.WebDriverManager;

public class GooglePage {
	@Test
	public void launchingoogle() throws Throwable {
		WebDriverManager.edgedriver().setup();
		EdgeOptions options = new EdgeOptions();
		options.addArguments("--disable-popup-blocking");
		options.addArguments("--disable-notifications");

		WebDriver driver = new EdgeDriver(options);
		driver.get("https://www.google.com/");
		driver.manage().window().maximize();
		Thread.sleep(6000);
		driver.findElement(By.xpath("//a[@aria-label='Google apps']")).click();
		//WebElement frame1 = driver.findElement(By.xpath("(//iframe[@role='presentation'])[2]"));
		WebElement frame1=driver.findElement(By.xpath("//iframe[@name='app']"));
		driver.switchTo().frame(frame1);
		List<WebElement> ele = driver.findElements(By.xpath("//li[@class='j1ei8c']//a[@class='tX9u1b']"));
		//List<WebElement> ele = driver.findElements(By.xpath("//li[@jscontroller='lKZxSd']"));
		int total=ele.size();
		System.out.println("the total apps in the store is "+total);
		for (int i = 0; i < ele.size(); i++) {
			
			System.out.println(ele.get(i).getText());
			JavascriptExecutor jsp=(JavascriptExecutor)(driver);
			if (ele.get(i).getText().equalsIgnoreCase("Chrome Web Store")) {
				jsp.executeScript("arguments[0].scrollIntoView(true);", ele.get(i));
				ele.get(i).click();
				break;
			}
			

		}
		Thread.sleep(3000);
		driver.navigate().back();
		driver.switchTo().defaultContent();
		Thread.sleep(3000);
		driver.findElement(By.xpath("//div[@jsname='vdLsw']/following-sibling::textarea[@class='gLFyf']")).sendKeys("Images",Keys.ENTER);
	//	ArrayList<String> tabs = new ArrayList<String>(driver.getWindowHandles());
		//driver.switchTo().window(tabs.get(1));
	}

}
