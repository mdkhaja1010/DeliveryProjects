package com.TestRunner;

import java.time.Duration;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class ActionsClassValues {

	public static void main(String[] args) throws InterruptedException {
		WebDriver driver=new ChromeDriver();
		driver.manage().window().maximize();
		driver.get("https://kitap.kairostech.com/");
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(10));
		Thread.sleep(3000);
		driver.findElement(By.cssSelector("#email")).sendKeys("someshwar.d@kairostech.com",Keys.TAB,"Password@1",Keys.ENTER);
		Thread.sleep(5000);
		driver.findElement(By.xpath("(//*[contains(@class,'MuiButton-colorPrimary css-1vzxprf')])[2]")).click();
		Thread.sleep(3000);
		driver.findElement(By.xpath("//*[text()='Test Cases']")).click();
		Thread.sleep(3000);
		driver.findElement(By.xpath("(//*[text()='Applications'])[4]")).click();
		Thread.sleep(3000);
		driver.findElement(By.xpath("//*[text()='Orange HRMS Pranathi Test']")).click();
		Thread.sleep(3000);
		driver.findElement(By.xpath("//*[contains(@class,'MuiButtonBase-root MuiButton-root MuiButton-contained MuiButton-containedSuccess MuiButton-sizeSmall MuiButton-containedSizeSmall MuiButton-colorSuccess MuiButton-root MuiButton-contained MuiButton-containedSuccess MuiButton-sizeSmall ')]")).click();
		Thread.sleep(3000);
		driver.findElement(By.xpath("//*[contains(@class,'MuiButton-outlinedSizeSmall MuiButton-colorSuccess custom-button   css-1ksqobx')]")).click();
		Thread.sleep(3000);
		driver.findElement(By.xpath("//*[contains(@class,'MuiSelect-select MuiSelect-outlined Mui-error MuiInputBase-input MuiOutlinedInput-input MuiInputBase-inputSizeSmall css-dz5p8u')]")).click();
		Thread.sleep(3000);
		List<WebElement> values= driver.findElements(By.xpath("//*[contains(@class,'MuiList-root MuiList-padding MuiMenu-list')]//*[contains(@class,'MuiButtonBase-root MuiMenuItem-root MuiMenuItem-gutters MuiMenuItem-root')]"));
		//driver.findElement(By.xpath("//*[contains(@class,'MuiList-root MuiList-padding MuiMenu-list')]//*[contains(@class,'MuiButtonBase-root MuiMenuItem-root MuiMenuItem-gutters MuiMenuItem-root')]"))
		
		for(int i=0;i<values.size();i++) {
			System.out.println(values.get(i).getText());
		}
		
		
	}
}
