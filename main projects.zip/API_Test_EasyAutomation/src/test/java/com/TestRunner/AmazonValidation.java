package com.TestRunner;

import java.util.ArrayList;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Actions;
import org.testng.annotations.Test;

public class AmazonValidation {
	@Test
	public void setup() throws InterruptedException {
		WebDriver driver =new ChromeDriver();
		driver.manage().window().maximize();
		driver.get("https://www.amazon.in/");
		Thread.sleep(5000);
		driver.findElement(By.cssSelector("#twotabsearchtextbox")).sendKeys("samsumg mobiles");
		driver.findElement(By.cssSelector("#nav-search-submit-button")).click();
		Thread.sleep(3000);
		/*
		 * driver.findElement(By.
		 * xpath("//span[contains(text(),'Galaxy M34 5G (Prism Silver,6GB,128GB)')]")).
		 * click(); Thread.sleep(3000); ArrayList<String> listAllWindows= new ArrayList<
		 * >(driver.getWindowHandles());
		 * driver.switchTo().window(listAllWindows.get(1)); Thread.sleep(3000);
		 * driver.findElement(By.xpath("(//*[@id='add-to-cart-button'])[1]")).click();
		 * Thread.sleep(3000);
		 */
		WebElement ele=driver.findElement(By.cssSelector("[class$='s-lower-bound aok-relative'] input[id$='item_lower-bound-slider']"));
		JavascriptExecutor js=(JavascriptExecutor)driver;
		js.executeScript("arguments[0].scrollIntoView(true);", ele);
		Actions act=new Actions(driver);
		Thread.sleep(3000);
		act.moveToElement(ele, 100, 0).build().perform();
	}

}
