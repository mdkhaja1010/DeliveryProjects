package com.KhajaAutomationTrainer.package1;

import java.time.Duration;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeTest;

public class KhajaBaseClass {
	public WebDriver driver;
	
	@BeforeClass
	public void setup() {
	  driver=new ChromeDriver();
		driver.manage().window().maximize();
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(10));
		driver.get("https://admin-demo.nopcommerce.com/login");
		
		
	}

	@AfterClass
	public void tearDown() {
		driver.close();
	}
}
