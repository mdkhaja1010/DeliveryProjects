package com.testclass;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.testng.annotations.Test;

import com.KhajaAutomationTrainer.package1.KhajaBaseClass;

public class TestRun extends KhajaBaseClass{
	@Test
	public void run() throws InterruptedException {
		
		WebElement ele=driver.findElement(By.id("Email"));
		
		ele.clear();
		Thread.sleep(5000);
		ele.sendKeys("admin@yourstore.com");
		WebElement ele1=driver.findElement(By.id("Password"));
		ele1.clear();
		ele1.sendKeys("admin");
		driver.findElement(By.xpath("//button[text()='Log in']")).click();
		
	}

}
